clc;
clear;
close all;

alpha = 0.05;

% Load paired samples for the small-sample test.
smallX = load('groupSample3.mat');
smallX = smallX.groupSample3;
smallY = load('groupSample4.mat');
smallY = smallY.groupSample4;

% Load paired samples for the large-sample test.
largeX = load('groupSample5.mat');
largeX = largeX.groupSample5;
largeY = load('groupSample6.mat');
largeY = largeY.groupSample6;

% Wilcoxon signed-rank test for the small sample size.
[pSmallExact,hSmallExact,statsSmallExact] = signrank(smallX, smallY, ...
    'tail','both','alpha',alpha,'method','exact');
[pSmallApprox,hSmallApprox,statsSmallApprox] = signrank(smallX, smallY, ...
    'tail','both','alpha',alpha,'method','approximate');

% Wilcoxon signed-rank test for the large sample size.
[pLargeExact,hLargeExact,statsLargeExact] = signrank(largeX, largeY, ...
    'tail','both','alpha',alpha,'method','exact');
[pLargeApprox,hLargeApprox,statsLargeApprox] = signrank(largeX, largeY, ...
    'tail','both','alpha',alpha,'method','approximate');

% Display results.
fprintf('Wilcoxon signed-rank test results (alpha = %.2f)\n\n', alpha);

fprintf('Small sample (groupSample3 vs groupSample4)\n');
fprintf('  Exact      : p = %.6f, h = %d, statistic = %.4f\n', ...
    pSmallExact, hSmallExact, statsSmallExact.signedrank);
fprintf('  Approximate : p = %.6f, h = %d, statistic = %.4f\n\n', ...
    pSmallApprox, hSmallApprox, statsSmallApprox.signedrank);

fprintf('Large sample (groupSample5 vs groupSample6)\n');
fprintf('  Exact      : p = %.6f, h = %d, statistic = %.4f\n', ...
    pLargeExact, hLargeExact, statsLargeExact.signedrank);
fprintf('  Approximate : p = %.6f, h = %d, statistic = %.4f\n', ...
    pLargeApprox, hLargeApprox, statsLargeApprox.signedrank);
